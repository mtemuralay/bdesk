export const ETH_MNEMONIC =
  'test test test test test test test test test test test junk';
export const ETH_WALLET_PASSWORD = 'Tester@1234';
