import { BridgeHistoryPage } from 'app-portal';

export default function BridgeHistoryScreen() {
  return <BridgeHistoryPage />;
}
