import { BridgePage } from 'app-portal';

export default function BridgeScreen() {
  return <BridgePage />;
}
