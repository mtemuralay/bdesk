import { tv } from 'tailwind-variants';

export const styles = tv({
  slots: {
    utxos: 'bg-gray-3 mx-3 my-3 p-0 rounded',
  },
});
