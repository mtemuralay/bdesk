import { TxScreenSimple } from './TxScreenSimple';

export function TxScreenLoader() {
  return <TxScreenSimple isLoading />;
}
