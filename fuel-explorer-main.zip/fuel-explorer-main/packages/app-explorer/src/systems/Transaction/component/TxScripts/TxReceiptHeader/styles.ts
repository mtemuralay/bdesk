import { tv } from 'tailwind-variants';

export const styles = tv({
  slots: {
    header: 'group min-h-[42px] gap-2 tablet:gap-4',
  },
});
