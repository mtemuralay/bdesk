import { GQLReceiptType } from '@fuel-explorer/graphql/sdk';

export const RETURN_TYPES = [GQLReceiptType.Return, GQLReceiptType.ReturnData];
