import { EcosystemPage } from 'app-portal';

export default function EcosystemScreen() {
  return <EcosystemPage />;
}
