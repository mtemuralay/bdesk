export type AccountRouteParams = {
  id: string;
  tab: string;
};

export type AccountRouteProps = {
  params: AccountRouteParams;
};
