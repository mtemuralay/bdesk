export type ContractRouteParams = {
  id: string;
};

export type ContractRouteProps = {
  params: ContractRouteParams;
};
