'use client';
import { PageTitle } from 'app-commons';

export function TxsTitle() {
  return <PageTitle title="Recent Transactions" />;
}
