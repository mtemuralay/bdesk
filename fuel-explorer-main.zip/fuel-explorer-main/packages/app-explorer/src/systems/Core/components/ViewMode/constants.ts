export enum ViewModes {
  Simple = 'simple',
  Advanced = 'advanced',
}
