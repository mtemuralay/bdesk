import clsx from 'clsx';

export const cx = clsx;
