import { ErrorPageComponent } from '~/systems/Core/components/ErrorPage/ErrorPage';

export default function NotFound() {
  return <ErrorPageComponent />;
}
