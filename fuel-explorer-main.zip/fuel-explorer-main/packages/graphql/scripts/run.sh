#!/bin/bash

echo "Running Server"
pnpm server:start
