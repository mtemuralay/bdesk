import { LoadingBox } from '@fuels/ui';

export const InfoTextLoader = () => {
  return <LoadingBox className="w-[70px] h-4" />;
};
