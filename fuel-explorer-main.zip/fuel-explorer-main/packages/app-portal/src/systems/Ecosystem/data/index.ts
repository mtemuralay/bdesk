import projects from './projects.json';

import type { Project } from '../types';

const PROJECTS: Project[] = projects;

export { PROJECTS };
