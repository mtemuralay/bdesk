export enum Overlays {
  'tx.fromEth.toFuel' = 'tx.fromEth.toFuel',
  'tx.fromFuel.toEth' = 'tx.fromFuel.toEth',
  'fuel.install' = 'fuel.install',
  'eth.assets' = 'eth.assets',
}
