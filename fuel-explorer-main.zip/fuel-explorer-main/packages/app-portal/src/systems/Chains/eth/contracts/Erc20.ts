import contract from '@fuel-bridge/solidity-contracts/artifacts/contracts/test/Token.sol/Token.json';

export const ERC_20 = {
  abi: contract.abi,
};
