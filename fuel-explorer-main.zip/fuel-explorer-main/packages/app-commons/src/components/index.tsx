export type { PageTitleProps } from './PageTitle/PageTitle';
export { PageTitle } from './PageTitle/PageTitle';
