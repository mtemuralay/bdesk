---
"@fuels/ui": minor
---

Make the @fuels/ui package public and publishable
